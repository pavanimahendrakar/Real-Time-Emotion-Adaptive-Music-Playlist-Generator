const config = {
  spotify: {
    clientId: "3d402278ec5e45bc930e791de2741b3e",
    permissionScope:
      "playlist-read-private user-read-private playlist-modify-private playlist-modify-public"
  },
  siteUrl: "https://emotionify.nitratine.net"
};

export default config;
